<template>
  <div>
    <van-nav-bar left-arrow title="地图找房" @click-left="$router.back()" />
    <div id="container"></div>
  </div>
</template>

<script>
export default {
  mounted () {
    const data = [
      {
        label: '朝阳',
        value: 'AREA|69cc5f6d-4f29-a77c',
        coord: {
          latitude: '39.912338',
          longitude: '116.449979'
        },
        count: 661
      },
      {
        label: '丰台',
        value: 'AREA|0dd58113-90ab-4d85',
        coord: {
          latitude: '39.858097',
          longitude: '116.292081'
        },
        count: 214
      },
      {
        label: '西城',
        value: 'AREA|fdb2a2a2-519c-9cf7',
        coord: {
          latitude: '39.958385',
          longitude: '116.399275'
        },
        count: 386
      }
    ]
    const { BMapGL } = window
    const map = new BMapGL.Map('container')
    map.centerAndZoom(new BMapGL.Point(data[0].coord.longitude, data[0].coord.latitude), 18)
    map.enableScrollWheelZoom(true)
    data.forEach(obj => {
      console.log(obj)
      const opts = {
        position: new BMapGL.Point(obj.coord.latitude, obj.coord.longitude), // 指定文本标注所在的地理位置
        offset: new BMapGL.Size(30, -30) // 设置文本偏移量
      }
      // 创建文本标注对象
      const label = new BMapGL.Label(`<span>${obj.label}</span><br/><span>${obj.count}套</span>`, opts)
      // 自定义文本标注样式
      label.setStyle({
        color: '#fff',
        borderColor: '#fff',
        backgroundColor: '#23bb78',
        padding: '14px 0 0',
        fontSize: '12px',
        textAlign: 'center',
        boxSizing: ' border-box',
        lineHeight: '18px',
        height: '70px',
        width: '70px',
        borderRadius: '50%',
        fontFamily: '微软雅黑'
      })
      map.addOverlay(label)
    })
  },
  created () { },
  data () {
    return {

    }
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped lang='less'>
html {
  height: 100%;
}
body {
  height: 100%;
  margin: 0px;
  padding: 0px;
}
#container {
  height: 750px;
}
/deep/p {
  text-align: center;
  margin: 0 !important;
}
</style>
